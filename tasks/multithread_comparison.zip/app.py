
from flask import Flask, jsonify, request, render_template, send_file
from threading import Thread
from concurrent.futures import ThreadPoolExecutor
from utils import compute_primes
import time
import os

app = Flask(__name__)
executor = ThreadPoolExecutor(max_workers=5)
results = {}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/simple-thread")
def simple_thread():
    task_id = str(time.time())
    limit = int(request.args.get("limit", 50000))

    def task():
        result = compute_primes(limit, "simple-thread")
        results[task_id] = result

    thread = Thread(target=task)
    thread.start()

    return jsonify({"status": "started", "task_id": task_id})

@app.route("/thread-pool")
def thread_pool():
    task_id = str(time.time())
    limit = int(request.args.get("limit", 50000))

    def task():
        result = compute_primes(limit, "thread-pool")
        results[task_id] = result

    executor.submit(task)
    return jsonify({"status": "queued", "task_id": task_id})

@app.route("/result/<task_id>")
def check_result(task_id):
    if task_id in results:
        return jsonify({"task_id": task_id, "result": results[task_id]})
    else:
        return jsonify({"status": "pending", "task_id": task_id})

@app.route("/download-results")
def download_results():
    path = "benchmark_results.csv"
    if os.path.exists(path):
        return send_file(path, as_attachment=True)
    else:
        return "No benchmark results found.", 404

if __name__ == "__main__":
    app.run(debug=True, port=5050)
