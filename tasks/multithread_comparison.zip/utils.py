
import time
import psutil
import os
import csv

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return False
    return True

def compute_primes(limit, model_type):
    process = psutil.Process(os.getpid())
    cpu_before = psutil.cpu_percent(interval=None)
    mem_before = process.memory_info().rss / 1024 / 1024  # in MB

    start = time.time()
    primes = [n for n in range(limit) if is_prime(n)]
    duration = time.time() - start

    cpu_after = psutil.cpu_percent(interval=None)
    mem_after = process.memory_info().rss / 1024 / 1024  # in MB

    result = {
        "count": len(primes),
        "duration": round(duration, 3),
        "cpu_percent": cpu_after,
        "memory_usage_mb": round(mem_after - mem_before, 2)
    }

    try:
        with open("benchmark_results.csv", "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                model_type,
                limit,
                result["count"],
                result["duration"],
                result["cpu_percent"],
                result["memory_usage_mb"],
                time.strftime("%Y-%m-%d %H:%M:%S")
            ])
    except Exception as e:
        print("Error writing CSV:", e)

    return result
